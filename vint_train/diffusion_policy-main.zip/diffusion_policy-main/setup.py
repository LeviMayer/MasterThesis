from setuptools import setup, find_packages

setup(
  name = 'diffusion_policy',
  packages = find_packages(),
)
